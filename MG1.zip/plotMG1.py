import matplotlib.pyplot as plt
import numpy as np

data_cv = np.loadtxt("results/sens_cv.data")

x = data_cv[:, 0]
y_resp, yerr_resp = data_cv[:, 11], data_cv[:, 12]
y_srv, yerr_srv = data_cv[:, 7], data_cv[:, 8]
y_wait, yerr_wait = data_cv[:, 9], data_cv[:, 10]
y_delay, yerr_delay = data_cv[:, 13], data_cv[:, 14]

rho = 0.8

# Define theoretical curves
mg1_theory = lambda x: 0.1 * (1 + ((1 + (x)**2)/2) * rho / (1 - rho)) + 0.1
mm1_theory = lambda x: 0.1 * (1 / (1 - rho)) + 0.1

plt.figure(figsize=(10, 6))
plt.errorbar(x, y_resp, yerr=yerr_resp, fmt='o', label=r'$T_{Resp} (sim)$', color='C1', markersize=6)
plt.plot(x, y_resp, label='_nolegend_', color='C1')
plt.errorbar(x, y_srv, yerr=yerr_srv, fmt='o', label=r'$T_{Srv} (sim)$', color='C2', markersize=6)
plt.plot(x, y_srv, label='_nolegend_', color='C2')
plt.errorbar(x, y_wait, yerr=yerr_wait, fmt='o', label=r'$T_{Wait} (sim)$', color='C3', markersize=6)
plt.plot(x, y_wait, label='_nolegend_', color='C3')
plt.errorbar(x, y_delay, yerr=yerr_delay, fmt='o', label=r'$T_{Delay} (sim)$', color='C4', markersize=6)
plt.plot(x, y_delay, label='_nolegend_', color='C4')

x_theory = np.linspace(min(x), max(x), 400)
plt.plot(x_theory, [mg1_theory(x) for x in x_theory], label=r'$M/G/1 (theory)$', color='C6')
plt.plot(x_theory, [mm1_theory(x) for x in x_theory], label=r'$M/M/1 (theory)$', color='C7')

plt.xlim(left=min(x), right=max(x))
plt.ylim(0, 0.9)
plt.xlabel(r'$\sigma \mu$', fontsize=12)
plt.ylabel('Time [s]', fontsize=12)
plt.legend(loc='upper left')

plt.savefig("TrespMG1.png", dpi=300, bbox_inches='tight')
